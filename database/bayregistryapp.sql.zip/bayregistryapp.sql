-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 08, 2021 at 07:47 AM
-- Server version: 5.7.24
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bayregistryapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `allocations`
--

CREATE TABLE `allocations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `beneficiaries`
--

CREATE TABLE `beneficiaries` (
  `id` int(11) NOT NULL,
  `firstname` varchar(191) NOT NULL,
  `middlename` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `age` int(11) NOT NULL,
  `occupation` varchar(32) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `education_id` bigint(20) DEFAULT NULL,
  `benefit_id` varchar(128) NOT NULL,
  `status_id` varchar(16) NOT NULL,
  `state_id` varchar(32) NOT NULL,
  `lga_id` varchar(32) NOT NULL,
  `community_id` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `beneficiaries2`
--

CREATE TABLE `beneficiaries2` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middlename` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `occupation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `education_id` bigint(20) UNSIGNED DEFAULT NULL,
  `benefit_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status_id` bigint(20) UNSIGNED DEFAULT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `lga_id` bigint(20) UNSIGNED DEFAULT NULL,
  `community_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `c2beneficiaries`
--

CREATE TABLE `c2beneficiaries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `benefit_id` bigint(20) UNSIGNED NOT NULL,
  `beneficiaries` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `c2beneficiaries`
--

INSERT INTO `c2beneficiaries` (`id`, `benefit_id`, `beneficiaries`, `created_at`, `updated_at`) VALUES
(1, 1, 300, '2021-03-26 15:47:01', '2021-03-26 15:47:01'),
(2, 2, 500, '2021-03-28 02:31:28', '2021-03-28 02:31:28');

-- --------------------------------------------------------

--
-- Table structure for table `classrooms`
--

CREATE TABLE `classrooms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` int(11) NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `communications`
--

CREATE TABLE `communications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` int(11) NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `communities`
--

CREATE TABLE `communities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `longtitude` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `lga_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `complains`
--

CREATE TABLE `complains` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` int(11) NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `components`
--

CREATE TABLE `components` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `components`
--

INSERT INTO `components` (`id`, `name`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Component 1', NULL, '2021-03-24 03:58:33', '2021-03-24 03:58:33', NULL),
(2, 'Component 2', NULL, '2021-03-24 04:20:51', '2021-03-24 23:45:12', NULL),
(3, 'Component 3', NULL, '2021-03-24 23:45:31', '2021-03-25 00:18:53', '2021-03-25 00:18:53'),
(4, 'Component 3', NULL, '2021-03-29 11:19:28', '2021-03-29 11:19:32', '2021-03-29 11:19:32');

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE `education` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `education_level` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`id`, `slug`, `education_level`, `created_at`, `updated_at`, `deleted_by`, `deleted_at`) VALUES
(1, 'e2521acd-1fff-497b-b011-41f51fdc2fb5', 'JSCE', '2021-03-29 13:05:02', '2021-03-29 13:05:02', NULL, NULL),
(2, '84bfd6b8-d654-4ae2-b42a-3c1aaf385231', 'SSCE', '2021-03-29 13:05:21', '2021-03-29 13:05:21', NULL, NULL),
(3, 'e1ef9aba-6a0b-46a5-a430-480f4da27b75', 'NCE', '2021-03-29 13:05:36', '2021-03-29 13:05:36', NULL, NULL),
(4, '548a847d-e2ee-4db1-951e-089154817d3b', 'OND', '2021-03-29 13:05:52', '2021-03-29 13:05:52', NULL, NULL),
(5, '32c55a28-ac2f-43a7-b00d-272e6aff702b', 'HND', '2021-03-29 13:06:08', '2021-03-29 13:06:08', NULL, NULL),
(6, '69244985-2164-4d1e-b2bf-b8967b50c427', 'BACHELOR DEGREE', '2021-03-29 13:06:43', '2021-03-29 13:06:43', NULL, NULL),
(7, 'aecfbe58-6b3d-476e-8f23-7d20e31a6b9b', 'MASTERS DEGREE', '2021-03-29 13:06:53', '2021-03-29 13:06:53', NULL, NULL),
(8, '864d4d41-cdd8-46a4-ab6d-f532cc0af374', 'OTHERS', '2021-03-29 13:07:13', '2021-03-29 13:07:13', NULL, NULL),
(9, '4f6774d3-7924-48b4-b12d-df39457cc199', 'NONE', '2021-03-29 13:07:27', '2021-03-29 13:07:27', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` int(11) NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `grms`
--

CREATE TABLE `grms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `lga_id` bigint(20) UNSIGNED DEFAULT NULL,
  `community` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `indicator` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `component` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brief_grieviance` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_report` date NOT NULL,
  `status_griviance` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_resolution` date NOT NULL,
  `brief_conclusion` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `level_resolution` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reported_by` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `investments`
--

CREATE TABLE `investments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lgas`
--

CREATE TABLE `lgas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `state_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lgas`
--

INSERT INTO `lgas` (`id`, `state_id`, `name`, `created_at`, `updated_at`) VALUES
(1, '1', 'Aba South', NULL, NULL),
(2, '1', 'Arochukwu', NULL, NULL),
(3, '1', 'Bende', NULL, NULL),
(4, '1', 'Ikwuano', NULL, NULL),
(5, '1', 'Isiala Ngwa North', NULL, NULL),
(6, '1', 'Isiala Ngwa South', NULL, NULL),
(7, '1', 'Isuikwuato', NULL, NULL),
(8, '1', 'Obi Ngwa', NULL, NULL),
(9, '1', 'Ohafia', NULL, NULL),
(10, '1', 'Osisioma', NULL, NULL),
(11, '1', 'Ugwunagbo', NULL, NULL),
(12, '1', 'Ukwa East', NULL, NULL),
(13, '1', 'Ukwa West', NULL, NULL),
(14, '1', 'Umuahia North', NULL, NULL),
(15, '1', 'Umuahia South', NULL, NULL),
(16, '1', 'Umu Nneochi', NULL, NULL),
(17, '2', 'Fufure', NULL, NULL),
(18, '2', 'Ganye', NULL, NULL),
(19, '2', 'Gayuk', NULL, NULL),
(20, '2', 'Gombi', NULL, NULL),
(21, '2', 'Grie', NULL, NULL),
(22, '2', 'Hong', NULL, NULL),
(23, '2', 'Jada', NULL, NULL),
(24, '2', 'Lamurde', NULL, NULL),
(25, '2', 'Madagali', NULL, NULL),
(26, '2', 'Maiha', NULL, NULL),
(27, '2', 'Mayo Belwa', NULL, NULL),
(28, '2', 'Michika', NULL, NULL),
(29, '2', 'Mubi North', NULL, NULL),
(30, '2', 'Mubi South', NULL, NULL),
(31, '2', 'Numan', NULL, NULL),
(32, '2', 'Shelleng', NULL, NULL),
(33, '2', 'Song', NULL, NULL),
(34, '2', 'Toungo', NULL, NULL),
(35, '2', 'Yola North', NULL, NULL),
(36, '2', 'Yola South', NULL, NULL),
(37, '3', 'Eastern Obolo', NULL, NULL),
(38, '3', 'Eket', NULL, NULL),
(39, '3', 'Esit Eket', NULL, NULL),
(40, '3', 'Essien Udim', NULL, NULL),
(41, '3', 'Etim Ekpo', NULL, NULL),
(42, '3', 'Etinan', NULL, NULL),
(43, '3', 'Ibeno', NULL, NULL),
(44, '3', 'Ibesikpo Asutan', NULL, NULL),
(45, '3', 'Ibiono-Ibom', NULL, NULL),
(46, '3', 'Ika', NULL, NULL),
(47, '3', 'Ikono', NULL, NULL),
(48, '3', 'Ikot Abasi', NULL, NULL),
(49, '3', 'Ikot Ekpene', NULL, NULL),
(50, '3', 'Ini', NULL, NULL),
(51, '3', 'Itu', NULL, NULL),
(52, '3', 'Mbo', NULL, NULL),
(53, '3', 'Mkpat-Enin', NULL, NULL),
(54, '3', 'Nsit-Atai', NULL, NULL),
(55, '3', 'Nsit-Ibom', NULL, NULL),
(56, '3', 'Nsit-Ubium', NULL, NULL),
(57, '3', 'Obot Akara', NULL, NULL),
(58, '3', 'Okobo', NULL, NULL),
(59, '3', 'Onna', NULL, NULL),
(60, '3', 'Oron', NULL, NULL),
(61, '3', 'Oruk Anam', NULL, NULL),
(62, '3', 'Udung-Uko', NULL, NULL),
(63, '3', 'Ukanafun', NULL, NULL),
(64, '3', 'Uruan', NULL, NULL),
(65, '3', 'Urue-Offong/Oruko', NULL, NULL),
(66, '3', 'Uyo', NULL, NULL),
(67, '4', 'Anambra East', NULL, NULL),
(68, '4', 'Anambra West', NULL, NULL),
(69, '4', 'Anaocha', NULL, NULL),
(70, '4', 'Awka North', NULL, NULL),
(71, '4', 'Awka South', NULL, NULL),
(72, '4', 'Ayamelum', NULL, NULL),
(73, '4', 'Dunukofia', NULL, NULL),
(74, '4', 'Ekwusigo', NULL, NULL),
(75, '4', 'Idemili North', NULL, NULL),
(76, '4', 'Idemili South', NULL, NULL),
(77, '4', 'Ihiala', NULL, NULL),
(78, '4', 'Njikoka', NULL, NULL),
(79, '4', 'Nnewi North', NULL, NULL),
(80, '4', 'Nnewi South', NULL, NULL),
(81, '4', 'Ogbaru', NULL, NULL),
(82, '4', 'Onitsha North', NULL, NULL),
(83, '4', 'Onitsha South', NULL, NULL),
(84, '4', 'Orumba North', NULL, NULL),
(85, '4', 'Orumba South', NULL, NULL),
(86, '4', 'Oyi', NULL, NULL),
(87, '5', 'Bauchi', NULL, NULL),
(88, '5', 'Bogoro', NULL, NULL),
(89, '5', 'Damban', NULL, NULL),
(90, '5', 'Darazo', NULL, NULL),
(91, '5', 'Dass', NULL, NULL),
(92, '5', 'Gamawa', NULL, NULL),
(93, '5', 'Ganjuwa', NULL, NULL),
(94, '5', 'Giade', NULL, NULL),
(95, '5', 'Itas/Gadau', NULL, NULL),
(96, '5', 'Jama\'are', NULL, NULL),
(97, '5', 'Katagum', NULL, NULL),
(98, '5', 'Kirfi', NULL, NULL),
(99, '5', 'Misau', NULL, NULL),
(100, '5', 'Ningi', NULL, NULL),
(101, '5', 'Shira', NULL, NULL),
(102, '5', 'Tafawa Balewa', NULL, NULL),
(103, '5', 'Toro', NULL, NULL),
(104, '5', 'Warji', NULL, NULL),
(105, '5', 'Zaki', NULL, NULL),
(106, '6', 'Ekeremor', NULL, NULL),
(107, '6', 'Kolokuma/Opokuma', NULL, NULL),
(108, '6', 'Nembe', NULL, NULL),
(109, '6', 'Ogbia', NULL, NULL),
(110, '6', 'Sagbama', NULL, NULL),
(111, '6', 'Southern Ijaw', NULL, NULL),
(112, '6', 'Yenagoa', NULL, NULL),
(113, '7', 'Apa', NULL, NULL),
(114, '7', 'Ado', NULL, NULL),
(115, '7', 'Buruku', NULL, NULL),
(116, '7', 'Gboko', NULL, NULL),
(117, '7', 'Guma', NULL, NULL),
(118, '7', 'Gwer East', NULL, NULL),
(119, '7', 'Gwer West', NULL, NULL),
(120, '7', 'Katsina-Ala', NULL, NULL),
(121, '7', 'Konshisha', NULL, NULL),
(122, '7', 'Kwande', NULL, NULL),
(123, '7', 'Logo', NULL, NULL),
(124, '7', 'Makurdi', NULL, NULL),
(125, '7', 'Obi', NULL, NULL),
(126, '7', 'Ogbadibo', NULL, NULL),
(127, '7', 'Ohimini', NULL, NULL),
(128, '7', 'Oju', NULL, NULL),
(129, '7', 'Okpokwu', NULL, NULL),
(130, '7', 'Oturkpo', NULL, NULL),
(131, '7', 'Tarka', NULL, NULL),
(132, '7', 'Ukum', NULL, NULL),
(133, '7', 'Ushongo', NULL, NULL),
(134, '7', 'Vandeikya', NULL, NULL),
(135, '8', 'Askira/Uba', NULL, NULL),
(136, '8', 'Bama', NULL, NULL),
(137, '8', 'Bayo', NULL, NULL),
(138, '8', 'Biu', NULL, NULL),
(139, '8', 'Chibok', NULL, NULL),
(140, '8', 'Damboa', NULL, NULL),
(141, '8', 'Dikwa', NULL, NULL),
(142, '8', 'Gubio', NULL, NULL),
(143, '8', 'Guzamala', NULL, NULL),
(144, '8', 'Gwoza', NULL, NULL),
(145, '8', 'Hawul', NULL, NULL),
(146, '8', 'Jere', NULL, NULL),
(147, '8', 'Kaga', NULL, NULL),
(148, '8', 'Kala/Balge', NULL, NULL),
(149, '8', 'Konduga', NULL, NULL),
(150, '8', 'Kukawa', NULL, NULL),
(151, '8', 'Kwaya Kusar', NULL, NULL),
(152, '8', 'Mafa', NULL, NULL),
(153, '8', 'Magumeri', NULL, NULL),
(154, '8', 'Maiduguri', NULL, NULL),
(155, '8', 'Marte', NULL, NULL),
(156, '8', 'Mobbar', NULL, NULL),
(157, '8', 'Monguno', NULL, NULL),
(158, '8', 'Ngala', NULL, NULL),
(159, '8', 'Nganzai', NULL, NULL),
(160, '8', 'Shani', NULL, NULL),
(161, '9', 'Akamkpa', NULL, NULL),
(162, '9', 'Akpabuyo', NULL, NULL),
(163, '9', 'Bakassi', NULL, NULL),
(164, '9', 'Bekwarra', NULL, NULL),
(165, '9', 'Biase', NULL, NULL),
(166, '9', 'Boki', NULL, NULL),
(167, '9', 'Calabar Municipal', NULL, NULL),
(168, '9', 'Calabar South', NULL, NULL),
(169, '9', 'Etung', NULL, NULL),
(170, '9', 'Ikom', NULL, NULL),
(171, '9', 'Obanliku', NULL, NULL),
(172, '9', 'Obubra', NULL, NULL),
(173, '9', 'Obudu', NULL, NULL),
(174, '9', 'Odukpani', NULL, NULL),
(175, '9', 'Ogoja', NULL, NULL),
(176, '9', 'Yakuur', NULL, NULL),
(177, '9', 'Yala', NULL, NULL),
(178, '10', 'Aniocha South', NULL, NULL),
(179, '10', 'Bomadi', NULL, NULL),
(180, '10', 'Burutu', NULL, NULL),
(181, '10', 'Ethiope East', NULL, NULL),
(182, '10', 'Ethiope West', NULL, NULL),
(183, '10', 'Ika North East', NULL, NULL),
(184, '10', 'Ika South', NULL, NULL),
(185, '10', 'Isoko North', NULL, NULL),
(186, '10', 'Isoko South', NULL, NULL),
(187, '10', 'Ndokwa East', NULL, NULL),
(188, '10', 'Ndokwa West', NULL, NULL),
(189, '10', 'Okpe', NULL, NULL),
(190, '10', 'Oshimili North', NULL, NULL),
(191, '10', 'Oshimili South', NULL, NULL),
(192, '10', 'Patani', NULL, NULL),
(193, '10', 'Sapele', NULL, NULL),
(194, '10', 'Udu', NULL, NULL),
(195, '10', 'Ughelli North', NULL, NULL),
(196, '10', 'Ughelli South', NULL, NULL),
(197, '10', 'Ukwuani', NULL, NULL),
(198, '10', 'Uvwie', NULL, NULL),
(199, '10', 'Warri North', NULL, NULL),
(200, '10', 'Warri South', NULL, NULL),
(201, '10', 'Warri South West', NULL, NULL),
(202, '11', 'Afikpo North', NULL, NULL),
(203, '11', 'Afikpo South', NULL, NULL),
(204, '11', 'Ebonyi', NULL, NULL),
(205, '11', 'Ezza North', NULL, NULL),
(206, '11', 'Ezza South', NULL, NULL),
(207, '11', 'Ikwo', NULL, NULL),
(208, '11', 'Ishielu', NULL, NULL),
(209, '11', 'Ivo', NULL, NULL),
(210, '11', 'Izzi', NULL, NULL),
(211, '11', 'Ohaozara', NULL, NULL),
(212, '11', 'Ohaukwu', NULL, NULL),
(213, '11', 'Onicha', NULL, NULL),
(214, '12', 'Egor', NULL, NULL),
(215, '12', 'Esan Central', NULL, NULL),
(216, '12', 'Esan North-East', NULL, NULL),
(217, '12', 'Esan South-East', NULL, NULL),
(218, '12', 'Esan West', NULL, NULL),
(219, '12', 'Etsako Central', NULL, NULL),
(220, '12', 'Etsako East', NULL, NULL),
(221, '12', 'Etsako West', NULL, NULL),
(222, '12', 'Igueben', NULL, NULL),
(223, '12', 'Ikpoba Okha', NULL, NULL),
(224, '12', 'Orhionmwon', NULL, NULL),
(225, '12', 'Oredo', NULL, NULL),
(226, '12', 'Ovia North-East', NULL, NULL),
(227, '12', 'Ovia South-West', NULL, NULL),
(228, '12', 'Owan East', NULL, NULL),
(229, '12', 'Owan West', NULL, NULL),
(230, '12', 'Uhunmwonde', NULL, NULL),
(231, '13', 'Efon', NULL, NULL),
(232, '13', 'Ekiti East', NULL, NULL),
(233, '13', 'Ekiti South-West', NULL, NULL),
(234, '13', 'Ekiti West', NULL, NULL),
(235, '13', 'Emure', NULL, NULL),
(236, '13', 'Gbonyin', NULL, NULL),
(237, '13', 'Ido Osi', NULL, NULL),
(238, '13', 'Ijero', NULL, NULL),
(239, '13', 'Ikere', NULL, NULL),
(240, '13', 'Ikole', NULL, NULL),
(241, '13', 'Ilejemeje', NULL, NULL),
(242, '13', 'Irepodun/Ifelodun', NULL, NULL),
(243, '13', 'Ise/Orun', NULL, NULL),
(244, '13', 'Moba', NULL, NULL),
(245, '13', 'Oye', NULL, NULL),
(246, '14', 'Awgu', NULL, NULL),
(247, '14', 'Enugu East', NULL, NULL),
(248, '14', 'Enugu North', NULL, NULL),
(249, '14', 'Enugu South', NULL, NULL),
(250, '14', 'Ezeagu', NULL, NULL),
(251, '14', 'Igbo Etiti', NULL, NULL),
(252, '14', 'Igbo Eze North', NULL, NULL),
(253, '14', 'Igbo Eze South', NULL, NULL),
(254, '14', 'Isi Uzo', NULL, NULL),
(255, '14', 'Nkanu East', NULL, NULL),
(256, '14', 'Nkanu West', NULL, NULL),
(257, '14', 'Nsukka', NULL, NULL),
(258, '14', 'Oji River', NULL, NULL),
(259, '14', 'Udenu', NULL, NULL),
(260, '14', 'Udi', NULL, NULL),
(261, '14', 'Uzo Uwani', NULL, NULL),
(262, '15', 'Bwari', NULL, NULL),
(263, '15', 'Gwagwalada', NULL, NULL),
(264, '15', 'Kuje', NULL, NULL),
(265, '15', 'Kwali', NULL, NULL),
(266, '15', 'Municipal Area Council', NULL, NULL),
(267, '16', 'Balanga', NULL, NULL),
(268, '16', 'Billiri', NULL, NULL),
(269, '16', 'Dukku', NULL, NULL),
(270, '16', 'Funakaye', NULL, NULL),
(271, '16', 'Gombe', NULL, NULL),
(272, '16', 'Kaltungo', NULL, NULL),
(273, '16', 'Kwami', NULL, NULL),
(274, '16', 'Nafada', NULL, NULL),
(275, '16', 'Shongom', NULL, NULL),
(276, '16', 'Yamaltu/Deba', NULL, NULL),
(277, '17', 'Ahiazu Mbaise', NULL, NULL),
(278, '17', 'Ehime Mbano', NULL, NULL),
(279, '17', 'Ezinihitte', NULL, NULL),
(280, '17', 'Ideato North', NULL, NULL),
(281, '17', 'Ideato South', NULL, NULL),
(282, '17', 'Ihitte/Uboma', NULL, NULL),
(283, '17', 'Ikeduru', NULL, NULL),
(284, '17', 'Isiala Mbano', NULL, NULL),
(285, '17', 'Isu', NULL, NULL),
(286, '17', 'Mbaitoli', NULL, NULL),
(287, '17', 'Ngor Okpala', NULL, NULL),
(288, '17', 'Njaba', NULL, NULL),
(289, '17', 'Nkwerre', NULL, NULL),
(290, '17', 'Nwangele', NULL, NULL),
(291, '17', 'Obowo', NULL, NULL),
(292, '17', 'Oguta', NULL, NULL),
(293, '17', 'Ohaji/Egbema', NULL, NULL),
(294, '17', 'Okigwe', NULL, NULL),
(295, '17', 'Orlu', NULL, NULL),
(296, '17', 'Orsu', NULL, NULL),
(297, '17', 'Oru East', NULL, NULL),
(298, '17', 'Oru West', NULL, NULL),
(299, '17', 'Owerri Municipal', NULL, NULL),
(300, '17', 'Owerri North', NULL, NULL),
(301, '17', 'Owerri West', NULL, NULL),
(302, '17', 'Unuimo', NULL, NULL),
(303, '18', 'Babura', NULL, NULL),
(304, '18', 'Biriniwa', NULL, NULL),
(305, '18', 'Birnin Kudu', NULL, NULL),
(306, '18', 'Buji', NULL, NULL),
(307, '18', 'Dutse', NULL, NULL),
(308, '18', 'Gagarawa', NULL, NULL),
(309, '18', 'Garki', NULL, NULL),
(310, '18', 'Gumel', NULL, NULL),
(311, '18', 'Guri', NULL, NULL),
(312, '18', 'Gwaram', NULL, NULL),
(313, '18', 'Gwiwa', NULL, NULL),
(314, '18', 'Hadejia', NULL, NULL),
(315, '18', 'Jahun', NULL, NULL),
(316, '18', 'Kafin Hausa', NULL, NULL),
(317, '18', 'Kazaure', NULL, NULL),
(318, '18', 'Kiri Kasama', NULL, NULL),
(319, '18', 'Kiyawa', NULL, NULL),
(320, '18', 'Kaugama', NULL, NULL),
(321, '18', 'Maigatari', NULL, NULL),
(322, '18', 'Malam Madori', NULL, NULL),
(323, '18', 'Miga', NULL, NULL),
(324, '18', 'Ringim', NULL, NULL),
(325, '18', 'Roni', NULL, NULL),
(326, '18', 'Sule Tankarkar', NULL, NULL),
(327, '18', 'Taura', NULL, NULL),
(328, '18', 'Yankwashi', NULL, NULL),
(329, '19', 'Chikun', NULL, NULL),
(330, '19', 'Giwa', NULL, NULL),
(331, '19', 'Igabi', NULL, NULL),
(332, '19', 'Ikara', NULL, NULL),
(333, '19', 'Jaba', NULL, NULL),
(334, '19', 'Jema\'a', NULL, NULL),
(335, '19', 'Kachia', NULL, NULL),
(336, '19', 'Kaduna North', NULL, NULL),
(337, '19', 'Kaduna South', NULL, NULL),
(338, '19', 'Kagarko', NULL, NULL),
(339, '19', 'Kajuru', NULL, NULL),
(340, '19', 'Kaura', NULL, NULL),
(341, '19', 'Kauru', NULL, NULL),
(342, '19', 'Kubau', NULL, NULL),
(343, '19', 'Kudan', NULL, NULL),
(344, '19', 'Lere', NULL, NULL),
(345, '19', 'Makarfi', NULL, NULL),
(346, '19', 'Sabon Gari', NULL, NULL),
(347, '19', 'Sanga', NULL, NULL),
(348, '19', 'Soba', NULL, NULL),
(349, '19', 'Zangon Kataf', NULL, NULL),
(350, '19', 'Zaria', NULL, NULL),
(351, '20', 'Albasu', NULL, NULL),
(352, '20', 'Bagwai', NULL, NULL),
(353, '20', 'Bebeji', NULL, NULL),
(354, '20', 'Bichi', NULL, NULL),
(355, '20', 'Bunkure', NULL, NULL),
(356, '20', 'Dala', NULL, NULL),
(357, '20', 'Dambatta', NULL, NULL),
(358, '20', 'Dawakin Kudu', NULL, NULL),
(359, '20', 'Dawakin Tofa', NULL, NULL),
(360, '20', 'Doguwa', NULL, NULL),
(361, '20', 'Fagge', NULL, NULL),
(362, '20', 'Gabasawa', NULL, NULL),
(363, '20', 'Garko', NULL, NULL),
(364, '20', 'Garun Mallam', NULL, NULL),
(365, '20', 'Gaya', NULL, NULL),
(366, '20', 'Gezawa', NULL, NULL),
(367, '20', 'Gwale', NULL, NULL),
(368, '20', 'Gwarzo', NULL, NULL),
(369, '20', 'Kabo', NULL, NULL),
(370, '20', 'Kano Municipal', NULL, NULL),
(371, '20', 'Karaye', NULL, NULL),
(372, '20', 'Kibiya', NULL, NULL),
(373, '20', 'Kiru', NULL, NULL),
(374, '20', 'Kumbotso', NULL, NULL),
(375, '20', 'Kunchi', NULL, NULL),
(376, '20', 'Kura', NULL, NULL),
(377, '20', 'Madobi', NULL, NULL),
(378, '20', 'Makoda', NULL, NULL),
(379, '20', 'Minjibir', NULL, NULL),
(380, '20', 'Nasarawa', NULL, NULL),
(381, '20', 'Rano', NULL, NULL),
(382, '20', 'Rimin Gado', NULL, NULL),
(383, '20', 'Rogo', NULL, NULL),
(384, '20', 'Shanono', NULL, NULL),
(385, '20', 'Sumaila', NULL, NULL),
(386, '20', 'Takai', NULL, NULL),
(387, '20', 'Tarauni', NULL, NULL),
(388, '20', 'Tofa', NULL, NULL),
(389, '20', 'Tsanyawa', NULL, NULL),
(390, '20', 'Tudun Wada', NULL, NULL),
(391, '20', 'Ungogo', NULL, NULL),
(392, '20', 'Warawa', NULL, NULL),
(393, '20', 'Wudil', NULL, NULL),
(394, '21', 'Batagarawa', NULL, NULL),
(395, '21', 'Batsari', NULL, NULL),
(396, '21', 'Baure', NULL, NULL),
(397, '21', 'Bindawa', NULL, NULL),
(398, '21', 'Charanchi', NULL, NULL),
(399, '21', 'Dandume', NULL, NULL),
(400, '21', 'Danja', NULL, NULL),
(401, '21', 'Dan Musa', NULL, NULL),
(402, '21', 'Daura', NULL, NULL),
(403, '21', 'Dutsi', NULL, NULL),
(404, '21', 'Dutsin Ma', NULL, NULL),
(405, '21', 'Faskari', NULL, NULL),
(406, '21', 'Funtua', NULL, NULL),
(407, '21', 'Ingawa', NULL, NULL),
(408, '21', 'Jibia', NULL, NULL),
(409, '21', 'Kafur', NULL, NULL),
(410, '21', 'Kaita', NULL, NULL),
(411, '21', 'Kankara', NULL, NULL),
(412, '21', 'Kankia', NULL, NULL),
(413, '21', 'Katsina', NULL, NULL),
(414, '21', 'Kurfi', NULL, NULL),
(415, '21', 'Kusada', NULL, NULL),
(416, '21', 'Mai\'Adua', NULL, NULL),
(417, '21', 'Malumfashi', NULL, NULL),
(418, '21', 'Mani', NULL, NULL),
(419, '21', 'Mashi', NULL, NULL),
(420, '21', 'Matazu', NULL, NULL),
(421, '21', 'Musawa', NULL, NULL),
(422, '21', 'Rimi', NULL, NULL),
(423, '21', 'Sabuwa', NULL, NULL),
(424, '21', 'Safana', NULL, NULL),
(425, '21', 'Sandamu', NULL, NULL),
(426, '21', 'Zango', NULL, NULL),
(427, '22', 'Arewa Dandi', NULL, NULL),
(428, '22', 'Argungu', NULL, NULL),
(429, '22', 'Augie', NULL, NULL),
(430, '22', 'Bagudo', NULL, NULL),
(431, '22', 'Birnin Kebbi', NULL, NULL),
(432, '22', 'Bunza', NULL, NULL),
(433, '22', 'Dandi', NULL, NULL),
(434, '22', 'Fakai', NULL, NULL),
(435, '22', 'Gwandu', NULL, NULL),
(436, '22', 'Jega', NULL, NULL),
(437, '22', 'Kalgo', NULL, NULL),
(438, '22', 'Koko/Besse', NULL, NULL),
(439, '22', 'Maiyama', NULL, NULL),
(440, '22', 'Ngaski', NULL, NULL),
(441, '22', 'Sakaba', NULL, NULL),
(442, '22', 'Shanga', NULL, NULL),
(443, '22', 'Suru', NULL, NULL),
(444, '22', 'Wasagu/Danko', NULL, NULL),
(445, '22', 'Yauri', NULL, NULL),
(446, '22', 'Zuru', NULL, NULL),
(447, '23', 'Ajaokuta', NULL, NULL),
(448, '23', 'Ankpa', NULL, NULL),
(449, '23', 'Bassa', NULL, NULL),
(450, '23', 'Dekina', NULL, NULL),
(451, '23', 'Ibaji', NULL, NULL),
(452, '23', 'Idah', NULL, NULL),
(453, '23', 'Igalamela Odolu', NULL, NULL),
(454, '23', 'Ijumu', NULL, NULL),
(455, '23', 'Kabba/Bunu', NULL, NULL),
(456, '23', 'Kogi', NULL, NULL),
(457, '23', 'Lokoja', NULL, NULL),
(458, '23', 'Mopa Muro', NULL, NULL),
(459, '23', 'Ofu', NULL, NULL),
(460, '23', 'Ogori/Magongo', NULL, NULL),
(461, '23', 'Okehi', NULL, NULL),
(462, '23', 'Okene', NULL, NULL),
(463, '23', 'Olamaboro', NULL, NULL),
(464, '23', 'Omala', NULL, NULL),
(465, '23', 'Yagba East', NULL, NULL),
(466, '23', 'Yagba West', NULL, NULL),
(467, '24', 'Baruten', NULL, NULL),
(468, '24', 'Edu', NULL, NULL),
(469, '24', 'Ekiti', NULL, NULL),
(470, '24', 'Ifelodun', NULL, NULL),
(471, '24', 'Ilorin East', NULL, NULL),
(472, '24', 'Ilorin South', NULL, NULL),
(473, '24', 'Ilorin West', NULL, NULL),
(474, '24', 'Irepodun', NULL, NULL),
(475, '24', 'Isin', NULL, NULL),
(476, '24', 'Kaiama', NULL, NULL),
(477, '24', 'Moro', NULL, NULL),
(478, '24', 'Offa', NULL, NULL),
(479, '24', 'Oke Ero', NULL, NULL),
(480, '24', 'Oyun', NULL, NULL),
(481, '24', 'Pategi', NULL, NULL),
(482, '25', 'Ajeromi-Ifelodun', NULL, NULL),
(483, '25', 'Alimosho', NULL, NULL),
(484, '25', 'Amuwo-Odofin', NULL, NULL),
(485, '25', 'Apapa', NULL, NULL),
(486, '25', 'Badagry', NULL, NULL),
(487, '25', 'Epe', NULL, NULL),
(488, '25', 'Eti Osa', NULL, NULL),
(489, '25', 'Ibeju-Lekki', NULL, NULL),
(490, '25', 'Ifako-Ijaiye', NULL, NULL),
(491, '25', 'Ikeja', NULL, NULL),
(492, '25', 'Ikorodu', NULL, NULL),
(493, '25', 'Kosofe', NULL, NULL),
(494, '25', 'Lagos Island', NULL, NULL),
(495, '25', 'Lagos Mainland', NULL, NULL),
(496, '25', 'Mushin', NULL, NULL),
(497, '25', 'Ojo', NULL, NULL),
(498, '25', 'Oshodi-Isolo', NULL, NULL),
(499, '25', 'Shomolu', NULL, NULL),
(500, '25', 'Surulere', NULL, NULL),
(501, '26', 'Awe', NULL, NULL),
(502, '26', 'Doma', NULL, NULL),
(503, '26', 'Karu', NULL, NULL),
(504, '26', 'Keana', NULL, NULL),
(505, '26', 'Keffi', NULL, NULL),
(506, '26', 'Kokona', NULL, NULL),
(507, '26', 'Lafia', NULL, NULL),
(508, '26', 'Nasarawa', NULL, NULL),
(509, '26', 'Nasarawa Egon', NULL, NULL),
(510, '26', 'Obi', NULL, NULL),
(511, '26', 'Toto', NULL, NULL),
(512, '26', 'Wamba', NULL, NULL),
(513, '27', 'Agwara', NULL, NULL),
(514, '27', 'Bida', NULL, NULL),
(515, '27', 'Borgu', NULL, NULL),
(516, '27', 'Bosso', NULL, NULL),
(517, '27', 'Chanchaga', NULL, NULL),
(518, '27', 'Edati', NULL, NULL),
(519, '27', 'Gbako', NULL, NULL),
(520, '27', 'Gurara', NULL, NULL),
(521, '27', 'Katcha', NULL, NULL),
(522, '27', 'Kontagora', NULL, NULL),
(523, '27', 'Lapai', NULL, NULL),
(524, '27', 'Lavun', NULL, NULL),
(525, '27', 'Magama', NULL, NULL),
(526, '27', 'Mariga', NULL, NULL),
(527, '27', 'Mashegu', NULL, NULL),
(528, '27', 'Mokwa', NULL, NULL),
(529, '27', 'Moya', NULL, NULL),
(530, '27', 'Paikoro', NULL, NULL),
(531, '27', 'Rafi', NULL, NULL),
(532, '27', 'Rijau', NULL, NULL),
(533, '27', 'Shiroro', NULL, NULL),
(534, '27', 'Suleja', NULL, NULL),
(535, '27', 'Tafa', NULL, NULL),
(536, '27', 'Wushishi', NULL, NULL),
(537, '28', 'Abeokuta South', NULL, NULL),
(538, '28', 'Ado-Odo/Ota', NULL, NULL),
(539, '28', 'Egbado North', NULL, NULL),
(540, '28', 'Egbado South', NULL, NULL),
(541, '28', 'Ewekoro', NULL, NULL),
(542, '28', 'Ifo', NULL, NULL),
(543, '28', 'Ijebu East', NULL, NULL),
(544, '28', 'Ijebu North', NULL, NULL),
(545, '28', 'Ijebu North East', NULL, NULL),
(546, '28', 'Ijebu Ode', NULL, NULL),
(547, '28', 'Ikenne', NULL, NULL),
(548, '28', 'Imeko Afon', NULL, NULL),
(549, '28', 'Ipokia', NULL, NULL),
(550, '28', 'Obafemi Owode', NULL, NULL),
(551, '28', 'Odeda', NULL, NULL),
(552, '28', 'Odogbolu', NULL, NULL),
(553, '28', 'Ogun Waterside', NULL, NULL),
(554, '28', 'Remo North', NULL, NULL),
(555, '28', 'Shagamu', NULL, NULL),
(556, '29', 'Akoko North-West', NULL, NULL),
(557, '29', 'Akoko South-West', NULL, NULL),
(558, '29', 'Akoko South-East', NULL, NULL),
(559, '29', 'Akure North', NULL, NULL),
(560, '29', 'Akure South', NULL, NULL),
(561, '29', 'Ese Odo', NULL, NULL),
(562, '29', 'Idanre', NULL, NULL),
(563, '29', 'Ifedore', NULL, NULL),
(564, '29', 'Ilaje', NULL, NULL),
(565, '29', 'Ile Oluji/Okeigbo', NULL, NULL),
(566, '29', 'Irele', NULL, NULL),
(567, '29', 'Odigbo', NULL, NULL),
(568, '29', 'Okitipupa', NULL, NULL),
(569, '29', 'Ondo East', NULL, NULL),
(570, '29', 'Ondo West', NULL, NULL),
(571, '29', 'Ose', NULL, NULL),
(572, '29', 'Owo', NULL, NULL),
(573, '30', 'Atakunmosa West', NULL, NULL),
(574, '30', 'Aiyedaade', NULL, NULL),
(575, '30', 'Aiyedire', NULL, NULL),
(576, '30', 'Boluwaduro', NULL, NULL),
(577, '30', 'Boripe', NULL, NULL),
(578, '30', 'Ede North', NULL, NULL),
(579, '30', 'Ede South', NULL, NULL),
(580, '30', 'Ife Central', NULL, NULL),
(581, '30', 'Ife East', NULL, NULL),
(582, '30', 'Ife North', NULL, NULL),
(583, '30', 'Ife South', NULL, NULL),
(584, '30', 'Egbedore', NULL, NULL),
(585, '30', 'Ejigbo', NULL, NULL),
(586, '30', 'Ifedayo', NULL, NULL),
(587, '30', 'Ifelodun', NULL, NULL),
(588, '30', 'Ila', NULL, NULL),
(589, '30', 'Ilesa East', NULL, NULL),
(590, '30', 'Ilesa West', NULL, NULL),
(591, '30', 'Irepodun', NULL, NULL),
(592, '30', 'Irewole', NULL, NULL),
(593, '30', 'Isokan', NULL, NULL),
(594, '30', 'Iwo', NULL, NULL),
(595, '30', 'Obokun', NULL, NULL),
(596, '30', 'Odo Otin', NULL, NULL),
(597, '30', 'Ola Oluwa', NULL, NULL),
(598, '30', 'Olorunda', NULL, NULL),
(599, '30', 'Oriade', NULL, NULL),
(600, '30', 'Orolu', NULL, NULL),
(601, '30', 'Osogbo', NULL, NULL),
(602, '31', 'Akinyele', NULL, NULL),
(603, '31', 'Atiba', NULL, NULL),
(604, '31', 'Atisbo', NULL, NULL),
(605, '31', 'Egbeda', NULL, NULL),
(606, '31', 'Ibadan North', NULL, NULL),
(607, '31', 'Ibadan North-East', NULL, NULL),
(608, '31', 'Ibadan North-West', NULL, NULL),
(609, '31', 'Ibadan South-East', NULL, NULL),
(610, '31', 'Ibadan South-West', NULL, NULL),
(611, '31', 'Ibarapa Central', NULL, NULL),
(612, '31', 'Ibarapa East', NULL, NULL),
(613, '31', 'Ibarapa North', NULL, NULL),
(614, '31', 'Ido', NULL, NULL),
(615, '31', 'Irepo', NULL, NULL),
(616, '31', 'Iseyin', NULL, NULL),
(617, '31', 'Itesiwaju', NULL, NULL),
(618, '31', 'Iwajowa', NULL, NULL),
(619, '31', 'Kajola', NULL, NULL),
(620, '31', 'Lagelu', NULL, NULL),
(621, '31', 'Ogbomosho North', NULL, NULL),
(622, '31', 'Ogbomosho South', NULL, NULL),
(623, '31', 'Ogo Oluwa', NULL, NULL),
(624, '31', 'Olorunsogo', NULL, NULL),
(625, '31', 'Oluyole', NULL, NULL),
(626, '31', 'Ona Ara', NULL, NULL),
(627, '31', 'Orelope', NULL, NULL),
(628, '31', 'Ori Ire', NULL, NULL),
(629, '31', 'Oyo', NULL, NULL),
(630, '31', 'Oyo East', NULL, NULL),
(631, '31', 'Saki East', NULL, NULL),
(632, '31', 'Saki West', NULL, NULL),
(633, '31', 'Surulere', NULL, NULL),
(634, '32', 'Barkin Ladi', NULL, NULL),
(635, '32', 'Bassa', NULL, NULL),
(636, '32', 'Jos East', NULL, NULL),
(637, '32', 'Jos North', NULL, NULL),
(638, '32', 'Jos South', NULL, NULL),
(639, '32', 'Kanam', NULL, NULL),
(640, '32', 'Kanke', NULL, NULL),
(641, '32', 'Langtang South', NULL, NULL),
(642, '32', 'Langtang North', NULL, NULL),
(643, '32', 'Mangu', NULL, NULL),
(644, '32', 'Mikang', NULL, NULL),
(645, '32', 'Pankshin', NULL, NULL),
(646, '32', 'Qua\'an Pan', NULL, NULL),
(647, '32', 'Riyom', NULL, NULL),
(648, '32', 'Shendam', NULL, NULL),
(649, '32', 'Wase', NULL, NULL),
(650, '33', 'Ahoada East', NULL, NULL),
(651, '33', 'Ahoada West', NULL, NULL),
(652, '33', 'Akuku-Toru', NULL, NULL),
(653, '33', 'Andoni', NULL, NULL),
(654, '33', 'Asari-Toru', NULL, NULL),
(655, '33', 'Bonny', NULL, NULL),
(656, '33', 'Degema', NULL, NULL),
(657, '33', 'Eleme', NULL, NULL),
(658, '33', 'Emuoha', NULL, NULL),
(659, '33', 'Etche', NULL, NULL),
(660, '33', 'Gokana', NULL, NULL),
(661, '33', 'Ikwerre', NULL, NULL),
(662, '33', 'Khana', NULL, NULL),
(663, '33', 'Obio/Akpor', NULL, NULL),
(664, '33', 'Ogba/Egbema/Ndoni', NULL, NULL),
(665, '33', 'Ogu/Bolo', NULL, NULL),
(666, '33', 'Okrika', NULL, NULL),
(667, '33', 'Omuma', NULL, NULL),
(668, '33', 'Opobo/Nkoro', NULL, NULL),
(669, '33', 'Oyigbo', NULL, NULL),
(670, '33', 'Port Harcourt', NULL, NULL),
(671, '33', 'Tai', NULL, NULL),
(672, '34', 'Bodinga', NULL, NULL),
(673, '34', 'Dange Shuni', NULL, NULL),
(674, '34', 'Gada', NULL, NULL),
(675, '34', 'Goronyo', NULL, NULL),
(676, '34', 'Gudu', NULL, NULL),
(677, '34', 'Gwadabawa', NULL, NULL),
(678, '34', 'Illela', NULL, NULL),
(679, '34', 'Isa', NULL, NULL),
(680, '34', 'Kebbe', NULL, NULL),
(681, '34', 'Kware', NULL, NULL),
(682, '34', 'Rabah', NULL, NULL),
(683, '34', 'Sabon Birni', NULL, NULL),
(684, '34', 'Shagari', NULL, NULL),
(685, '34', 'Silame', NULL, NULL),
(686, '34', 'Sokoto North', NULL, NULL),
(687, '34', 'Sokoto South', NULL, NULL),
(688, '34', 'Tambuwal', NULL, NULL),
(689, '34', 'Tangaza', NULL, NULL),
(690, '34', 'Tureta', NULL, NULL),
(691, '34', 'Wamako', NULL, NULL),
(692, '34', 'Wurno', NULL, NULL),
(693, '34', 'Yabo', NULL, NULL),
(694, '35', 'Bali', NULL, NULL),
(695, '35', 'Donga', NULL, NULL),
(696, '35', 'Gashaka', NULL, NULL),
(697, '35', 'Gassol', NULL, NULL),
(698, '35', 'Ibi', NULL, NULL),
(699, '35', 'Jalingo', NULL, NULL),
(700, '35', 'Karim Lamido', NULL, NULL),
(701, '35', 'Kumi', NULL, NULL),
(702, '35', 'Lau', NULL, NULL),
(703, '35', 'Sardauna', NULL, NULL),
(704, '35', 'Takum', NULL, NULL),
(705, '35', 'Ussa', NULL, NULL),
(706, '35', 'Wukari', NULL, NULL),
(707, '35', 'Yorro', NULL, NULL),
(708, '35', 'Zing', NULL, NULL),
(709, '36', 'Bursari', NULL, NULL),
(710, '36', 'Damaturu', NULL, NULL),
(711, '36', 'Fika', NULL, NULL),
(712, '36', 'Fune', NULL, NULL),
(713, '36', 'Geidam', NULL, NULL),
(714, '36', 'Gujba', NULL, NULL),
(715, '36', 'Gulani', NULL, NULL),
(716, '36', 'Jakusko', NULL, NULL),
(717, '36', 'Karasuwa', NULL, NULL),
(718, '36', 'Machina', NULL, NULL),
(719, '36', 'Nangere', NULL, NULL),
(720, '36', 'Nguru', NULL, NULL),
(721, '36', 'Potiskum', NULL, NULL),
(722, '36', 'Tarmuwa', NULL, NULL),
(723, '36', 'Yunusari', NULL, NULL),
(724, '36', 'Yusufari', NULL, NULL),
(725, '37', 'Bakura', NULL, NULL),
(726, '37', 'Birnin Magaji/Kiyaw', NULL, NULL),
(727, '37', 'Bukkuyum', NULL, NULL),
(728, '37', 'Bungudu', NULL, NULL),
(729, '37', 'Gummi', NULL, NULL),
(730, '37', 'Gusau', NULL, NULL),
(731, '37', 'Kaura Namoda', NULL, NULL),
(732, '37', 'Maradun', NULL, NULL),
(733, '37', 'Maru', NULL, NULL),
(734, '37', 'Shinkafi', NULL, NULL),
(735, '37', 'Talata Mafara', NULL, NULL),
(736, '37', 'Chafe', NULL, NULL),
(737, '37', 'Zurmi', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_03_09_135529_create_permission_tables', 1),
(5, '2016_06_01_000001_create_oauth_auth_codes_table', 2),
(6, '2016_06_01_000002_create_oauth_access_tokens_table', 2),
(7, '2016_06_01_000003_create_oauth_refresh_tokens_table', 2),
(8, '2016_06_01_000004_create_oauth_clients_table', 2),
(9, '2016_06_01_000005_create_oauth_personal_access_clients_table', 2),
(10, '2021_01_23_063825_create_states_table', 3),
(11, '2021_01_23_063916_create_lgas_table', 3),
(12, '2021_01_25_120335_create_communities_table', 3),
(13, '2021_01_25_215128_create_education_table', 3),
(14, '2021_01_26_062454_create_benefits_table', 3),
(15, '2021_01_26_062537_create_statuses_table', 3),
(16, '2021_01_26_113016_create_beneficiaries_table', 3),
(17, '2021_01_28_173121_add_delete_at_to_beneficiaries_table', 3),
(18, '2021_01_28_181101_add_deleted_at_to_benefits_table', 3),
(19, '2021_01_28_181339_add_deleted_at_to_communities_table', 3),
(20, '2021_01_28_181427_add_deleted_at_to_education_table', 3),
(21, '2021_01_28_181532_add_deleted_at_to_statuses_table', 3),
(22, '2021_02_02_043052_create_trackers_table', 3),
(23, '2021_02_03_102036_create_reports_table', 3),
(24, '2021_02_07_133439_create_grms_table', 3),
(25, '2021_02_09_081856_add_deleted_at_to_trackers_table', 3),
(26, '2021_02_09_082026_add_deleted_at_to_reports_table', 3),
(27, '2021_02_09_082103_add_deleted_at_to_grms_table', 3),
(28, '2021_02_15_105721_create_allocations_table', 3),
(29, '2021_02_15_230249_create_investments_table', 3),
(30, '2021_02_16_052542_create_projects_table', 3),
(31, '2021_02_17_092607_create_socials_table', 3),
(32, '2021_02_17_115400_create_peaces_table', 3),
(33, '2021_02_18_033307_create_trainings_table', 3),
(34, '2021_02_18_065129_create_feedback_table', 3),
(35, '2021_02_18_074929_create_complains_table', 3),
(36, '2021_02_18_081526_create_communications_table', 3),
(37, '2021_02_18_094953_create_transports_table', 3),
(38, '2021_02_18_131246_create_washes_table', 3),
(39, '2021_02_18_160215_create_pump__boreholes_table', 3),
(40, '2021_02_18_160335_create_schools_table', 3),
(41, '2021_02_18_160403_create_classrooms_table', 3),
(42, '2021_02_19_060348_create_scorecards_table', 3),
(45, '2021_03_23_041712_create_c2beneficiaries_table', 4),
(46, '2021_03_23_052236_create_components_table', 4),
(47, '2021_03_23_070507_update_components_table', 5),
(48, '2021_03_24_232034_update_benefits_table', 6),
(49, '2021_03_28_232539_update_states_table', 7),
(50, '2021_03_31_105411_create_welfares_table', 8);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\User', 1),
(3, 'App\\User', 2),
(4, 'App\\User', 3),
(2, 'App\\User', 4);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Themekit-Laravel-Admin-Panel Personal Access Client', 'UMWq3J9lINVBrWehpr7QJ9wOcoBp27o1PdJu5nN7', NULL, 'http://localhost', 1, 0, 0, '2020-05-10 03:51:41', '2020-05-10 03:51:41'),
(2, NULL, 'Themekit-Laravel-Admin-Panel Password Grant Client', 'A6CbTxyM5JHmF4Yk4BB2Bj23D4EnhEDac7TyuFCF', 'users', 'http://localhost', 0, 1, 0, '2020-05-10 03:51:41', '2020-05-10 03:51:41');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2020-05-10 03:51:41', '2020-05-10 03:51:41');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `occupations`
--

CREATE TABLE `occupations` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `occupations`
--

INSERT INTO `occupations` (`id`, `name`, `created_at`, `deleted_at`, `updated_at`) VALUES
(1, 'CIVIL SERVANT', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'ENTREPRENEUR', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'FARMER', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'STUDENT', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'OTHERS', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'UNEMPLOYED', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'HOMEMAKER', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `peaces`
--

CREATE TABLE `peaces` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `participant` int(11) NOT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(2, 'manage_role', 'web', '2020-03-10 19:10:57', '2020-03-10 19:10:57'),
(3, 'manage_permission', 'web', '2020-03-10 19:11:09', '2020-03-10 19:11:09'),
(4, 'manage_user', 'web', '2020-03-10 19:11:41', '2020-03-10 19:11:41'),
(5, 'manage_sales', 'web', '2020-03-12 16:46:39', '2020-03-12 16:46:39'),
(6, 'manage_projects', 'web', '2020-03-12 16:46:54', '2020-03-12 16:46:54');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `community_id` bigint(20) UNSIGNED DEFAULT NULL,
  `number` int(11) NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `longtitude` double NOT NULL,
  `latitude` double NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `component` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `video` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pump__boreholes`
--

CREATE TABLE `pump__boreholes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` int(11) NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `community` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `indicator` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `component` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `results` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `challenge` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `reported_by` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'web', '2020-03-10 18:40:47', '2020-03-10 18:40:47'),
(2, 'Admin', 'web', '2020-03-10 19:39:23', '2020-03-10 19:39:23'),
(3, 'Project Manager', 'web', '2020-03-12 19:11:50', '2020-03-12 19:11:50'),
(4, 'Sales Manager', 'web', '2020-03-12 19:12:07', '2020-03-12 19:12:07');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(4, 2),
(5, 2),
(6, 2),
(6, 3),
(5, 4);

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `scorecards`
--

CREATE TABLE `scorecards` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `component_one` int(11) NOT NULL,
  `component_two` int(11) NOT NULL,
  `safeguards` int(11) NOT NULL,
  `m_e` int(11) NOT NULL,
  `performance` int(11) NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `socials`
--

CREATE TABLE `socials` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` int(11) NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `participant_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` int(191) DEFAULT NULL,
  `me_officer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `slug`, `code`, `name`, `target`, `me_officer`, `contact`, `created_at`, `updated_at`) VALUES
(2, 'd6cef30d-5c76-4a6d-af72-42222e6fbb74', 'ADM', 'ADAMAWA', 22766, 'John Gaman', '08036087605', NULL, NULL),
(8, 'c58d52c6-5917-4b0b-92b8-2ff34f2a0a41', 'BRN', 'BORNO', 21770, 'Bako Alhaji', '08084245197', NULL, NULL),
(35, '22c1495d-c77e-4b6e-b367-f34caba8e373', 'YBE', 'YOBE', 22766, 'Baba Sambo', '0803 461 5562', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE `statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `statuses`
--

INSERT INTO `statuses` (`id`, `slug`, `name`, `created_at`, `updated_at`, `deleted_by`, `deleted_at`) VALUES
(1, '16eaea5f-73ce-4e68-85f9-d52269bee1e4', 'Community Member', '2021-03-29 13:34:42', '2021-03-29 13:34:42', NULL, NULL),
(2, '6cce8dae-b639-4b70-aa50-80ea8c488518', 'IDP Member', '2021-03-29 13:35:09', '2021-03-29 13:35:09', NULL, NULL),
(3, '39c283e5-9c5e-431d-8d81-3a2c184b83e6', 'Returnee', '2021-03-29 13:35:22', '2021-03-29 13:35:22', NULL, NULL),
(4, '817cc3fc-e167-4528-9285-584702f66263', 'Government Official', '2021-03-29 14:43:22', '2021-03-29 14:43:22', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `trackers`
--

CREATE TABLE `trackers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `indicator` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `female` int(11) DEFAULT '0',
  `male` int(11) DEFAULT '0',
  `other` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trainings`
--

CREATE TABLE `trainings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `training_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transports`
--

CREATE TABLE `transports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` int(11) NOT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'admin@test.com', NULL, '$2y$10$uZDwEdgAzi3wD4n8oBYfruvBmZJqVV7sSasFRZzlz5Wkqs0EyqiDe', NULL, NULL, '2020-03-12 19:28:44'),
(2, 'Project Manager', 'pm@test.com', NULL, '$2y$10$rm0yp.fuqPZevIkxlActtuBpMuTHLGwPRYFaNlA5TToZZqx.i7Tra', NULL, '2020-03-12 19:18:59', '2020-03-12 19:18:59'),
(3, 'Sales Manager', 'sm@test.com', NULL, '$2y$10$40lQm5lnWgtElBwnko7ASuUr.Obu2CI.hPecZ8ZciGsYKkXw2Kf3.', NULL, '2020-03-12 19:20:15', '2020-03-12 19:20:15'),
(4, 'HR', 'hr@test.com', NULL, '$2y$10$sFgFRrOZS4mzhRlAHbDIie.Kz.G3YSIYynnmcljjxVzyl0gkMQT6a', NULL, '2020-03-12 19:25:25', '2020-03-12 19:25:25');

-- --------------------------------------------------------

--
-- Table structure for table `washes`
--

CREATE TABLE `washes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` int(11) NOT NULL,
  `wash_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `welfares`
--

CREATE TABLE `welfares` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `component_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_number` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `welfares`
--

INSERT INTO `welfares` (`id`, `component_id`, `name`, `default_number`, `created_at`, `updated_at`) VALUES
(1, 1, 'Non farming Inputs', 1, '2021-03-31 11:14:51', NULL),
(2, 1, 'Agricultural inputs', 1, '2021-03-31 11:14:51', NULL),
(3, 1, 'Basic necessity kits', 1, '2021-03-31 11:14:51', NULL),
(4, 1, 'Peace/ Social cohesion initiatives ', 1, '2021-03-31 11:14:51', NULL),
(5, 1, 'Training & governance (crisis management and emergency response)', 1, '2021-03-31 11:14:51', NULL),
(6, 1, 'Soft skills (entrepreneurship)', 1, '2021-03-31 11:14:51', NULL),
(7, 1, 'Citizens engagement', 1, '2021-03-31 11:14:51', NULL),
(8, 1, 'Civic Education', 1, '2021-03-31 11:14:51', NULL),
(9, 1, 'Psycho social support', 1, '2021-03-31 11:14:51', NULL),
(10, 1, 'Non food items (refugee support kits)', 1, '2021-03-31 11:14:51', NULL),
(11, 1, 'Quick to market & Trading kits', 1, '2021-03-31 11:14:51', NULL),
(12, 1, 'Non agricultural livelihood kits', 1, '2021-03-31 11:14:51', NULL),
(13, 1, 'Small animal input', 1, '2021-03-31 11:14:51', NULL),
(14, 1, 'Agricultural kits', 1, '2021-03-31 11:14:51', NULL),
(15, 1, 'Grievance Redress Mechanism', 1, '2021-03-31 11:14:51', NULL),
(16, 1, 'Sensitisation and communication', 1, '2021-03-31 11:14:51', NULL),
(17, 1, 'Dispute resolution training', 1, '2021-03-31 11:14:51', NULL),
(18, 1, 'Sports for peace', 1, '2021-03-31 11:14:51', NULL),
(19, 1, 'Emergency management training', 1, '2021-03-31 11:14:51', NULL),
(20, 1, 'M and E training', 1, '2021-03-31 11:14:51', NULL),
(21, 1, 'Communication training ', 1, '2021-03-31 11:14:51', NULL),
(22, 1, 'Budget planning training', 1, '2021-03-31 11:14:51', NULL),
(23, 1, 'Training of health workers/ CHEWs.', 1, '2021-03-31 11:14:51', NULL),
(24, 2, 'PHC', 500, '2021-04-08 03:51:27', '2021-04-08 06:37:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `allocations`
--
ALTER TABLE `allocations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `allocations_slug_unique` (`slug`),
  ADD KEY `allocations_state_id_foreign` (`state_id`),
  ADD KEY `allocations_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `beneficiaries`
--
ALTER TABLE `beneficiaries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beneficiaries2`
--
ALTER TABLE `beneficiaries2`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `beneficiaries_slug_unique` (`slug`),
  ADD KEY `beneficiaries_education_id_foreign` (`education_id`),
  ADD KEY `beneficiaries_benefit_id_foreign` (`benefit_id`),
  ADD KEY `beneficiaries_status_id_foreign` (`status_id`),
  ADD KEY `beneficiaries_state_id_foreign` (`state_id`),
  ADD KEY `beneficiaries_lga_id_foreign` (`lga_id`),
  ADD KEY `beneficiaries_community_id_foreign` (`community_id`),
  ADD KEY `beneficiaries_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `c2beneficiaries`
--
ALTER TABLE `c2beneficiaries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classrooms`
--
ALTER TABLE `classrooms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `classrooms_slug_unique` (`slug`),
  ADD KEY `classrooms_state_id_foreign` (`state_id`),
  ADD KEY `classrooms_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `communications`
--
ALTER TABLE `communications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `communications_slug_unique` (`slug`),
  ADD KEY `communications_state_id_foreign` (`state_id`),
  ADD KEY `communications_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `communities`
--
ALTER TABLE `communities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `communities_slug_unique` (`slug`),
  ADD KEY `communities_state_id_foreign` (`state_id`),
  ADD KEY `communities_lga_id_foreign` (`lga_id`),
  ADD KEY `communities_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `complains`
--
ALTER TABLE `complains`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `complains_slug_unique` (`slug`),
  ADD KEY `complains_state_id_foreign` (`state_id`),
  ADD KEY `complains_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `components`
--
ALTER TABLE `components`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `education_slug_unique` (`slug`),
  ADD KEY `education_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `feedback_slug_unique` (`slug`),
  ADD KEY `feedback_state_id_foreign` (`state_id`),
  ADD KEY `feedback_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `grms`
--
ALTER TABLE `grms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `grms_slug_unique` (`slug`),
  ADD KEY `grms_state_id_foreign` (`state_id`),
  ADD KEY `grms_lga_id_foreign` (`lga_id`),
  ADD KEY `grms_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `investments`
--
ALTER TABLE `investments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `investments_slug_unique` (`slug`),
  ADD KEY `investments_state_id_foreign` (`state_id`),
  ADD KEY `investments_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `lgas`
--
ALTER TABLE `lgas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `occupations`
--
ALTER TABLE `occupations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `peaces`
--
ALTER TABLE `peaces`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `peaces_slug_unique` (`slug`),
  ADD KEY `peaces_state_id_foreign` (`state_id`),
  ADD KEY `peaces_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `projects_slug_unique` (`slug`),
  ADD KEY `projects_state_id_foreign` (`state_id`),
  ADD KEY `projects_community_id_foreign` (`community_id`),
  ADD KEY `projects_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `pump__boreholes`
--
ALTER TABLE `pump__boreholes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pump__boreholes_slug_unique` (`slug`),
  ADD KEY `pump__boreholes_state_id_foreign` (`state_id`),
  ADD KEY `pump__boreholes_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reports_slug_unique` (`slug`),
  ADD KEY `reports_state_id_foreign` (`state_id`),
  ADD KEY `reports_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `schools_slug_unique` (`slug`),
  ADD KEY `schools_state_id_foreign` (`state_id`),
  ADD KEY `schools_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `scorecards`
--
ALTER TABLE `scorecards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `scorecards_slug_unique` (`slug`),
  ADD KEY `scorecards_state_id_foreign` (`state_id`),
  ADD KEY `scorecards_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `socials`
--
ALTER TABLE `socials`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `socials_slug_unique` (`slug`),
  ADD KEY `socials_state_id_foreign` (`state_id`),
  ADD KEY `socials_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `states_slug_unique` (`slug`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `statuses_slug_unique` (`slug`),
  ADD KEY `statuses_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `trackers`
--
ALTER TABLE `trackers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `trackers_slug_unique` (`slug`),
  ADD KEY `trackers_state_id_foreign` (`state_id`),
  ADD KEY `trackers_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `trainings`
--
ALTER TABLE `trainings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `trainings_slug_unique` (`slug`),
  ADD KEY `trainings_state_id_foreign` (`state_id`),
  ADD KEY `trainings_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `transports`
--
ALTER TABLE `transports`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transports_slug_unique` (`slug`),
  ADD KEY `transports_state_id_foreign` (`state_id`),
  ADD KEY `transports_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `washes`
--
ALTER TABLE `washes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `washes_slug_unique` (`slug`),
  ADD KEY `washes_state_id_foreign` (`state_id`),
  ADD KEY `washes_deleted_by_foreign` (`deleted_by`);

--
-- Indexes for table `welfares`
--
ALTER TABLE `welfares`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `allocations`
--
ALTER TABLE `allocations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `beneficiaries`
--
ALTER TABLE `beneficiaries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `beneficiaries2`
--
ALTER TABLE `beneficiaries2`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c2beneficiaries`
--
ALTER TABLE `c2beneficiaries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `classrooms`
--
ALTER TABLE `classrooms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `communications`
--
ALTER TABLE `communications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `communities`
--
ALTER TABLE `communities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `complains`
--
ALTER TABLE `complains`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `components`
--
ALTER TABLE `components`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `education`
--
ALTER TABLE `education`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `grms`
--
ALTER TABLE `grms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `investments`
--
ALTER TABLE `investments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lgas`
--
ALTER TABLE `lgas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=738;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `occupations`
--
ALTER TABLE `occupations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `peaces`
--
ALTER TABLE `peaces`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pump__boreholes`
--
ALTER TABLE `pump__boreholes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scorecards`
--
ALTER TABLE `scorecards`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `socials`
--
ALTER TABLE `socials`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `trackers`
--
ALTER TABLE `trackers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trainings`
--
ALTER TABLE `trainings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transports`
--
ALTER TABLE `transports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `washes`
--
ALTER TABLE `washes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `welfares`
--
ALTER TABLE `welfares`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `allocations`
--
ALTER TABLE `allocations`
  ADD CONSTRAINT `allocations_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `allocations_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `beneficiaries2`
--
ALTER TABLE `beneficiaries2`
  ADD CONSTRAINT `beneficiaries_benefit_id_foreign` FOREIGN KEY (`benefit_id`) REFERENCES `benefits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `beneficiaries_community_id_foreign` FOREIGN KEY (`community_id`) REFERENCES `communities` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `beneficiaries_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `beneficiaries_education_id_foreign` FOREIGN KEY (`education_id`) REFERENCES `education` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `beneficiaries_lga_id_foreign` FOREIGN KEY (`lga_id`) REFERENCES `lgas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `beneficiaries_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `beneficiaries_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `classrooms`
--
ALTER TABLE `classrooms`
  ADD CONSTRAINT `classrooms_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `classrooms_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `communications`
--
ALTER TABLE `communications`
  ADD CONSTRAINT `communications_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `communications_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `communities`
--
ALTER TABLE `communities`
  ADD CONSTRAINT `communities_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `communities_lga_id_foreign` FOREIGN KEY (`lga_id`) REFERENCES `lgas` (`id`),
  ADD CONSTRAINT `communities_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`);

--
-- Constraints for table `complains`
--
ALTER TABLE `complains`
  ADD CONSTRAINT `complains_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `complains_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `education`
--
ALTER TABLE `education`
  ADD CONSTRAINT `education_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `feedback_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `grms`
--
ALTER TABLE `grms`
  ADD CONSTRAINT `grms_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `grms_lga_id_foreign` FOREIGN KEY (`lga_id`) REFERENCES `lgas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `grms_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `investments`
--
ALTER TABLE `investments`
  ADD CONSTRAINT `investments_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `investments_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `peaces`
--
ALTER TABLE `peaces`
  ADD CONSTRAINT `peaces_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `peaces_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_community_id_foreign` FOREIGN KEY (`community_id`) REFERENCES `communities` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `projects_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `projects_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pump__boreholes`
--
ALTER TABLE `pump__boreholes`
  ADD CONSTRAINT `pump__boreholes_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `pump__boreholes_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `reports_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `schools`
--
ALTER TABLE `schools`
  ADD CONSTRAINT `schools_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `schools_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `scorecards`
--
ALTER TABLE `scorecards`
  ADD CONSTRAINT `scorecards_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `scorecards_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `socials`
--
ALTER TABLE `socials`
  ADD CONSTRAINT `socials_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `socials_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `statuses`
--
ALTER TABLE `statuses`
  ADD CONSTRAINT `statuses_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `trackers`
--
ALTER TABLE `trackers`
  ADD CONSTRAINT `trackers_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `trackers_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `trainings`
--
ALTER TABLE `trainings`
  ADD CONSTRAINT `trainings_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `trainings_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transports`
--
ALTER TABLE `transports`
  ADD CONSTRAINT `transports_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `transports_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `washes`
--
ALTER TABLE `washes`
  ADD CONSTRAINT `washes_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `washes_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
